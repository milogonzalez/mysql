use libreria;

#1
select concat(apellido, ', ', nombre) empleado,
year(fecha_ingreso) as ingreso,
timestampdiff(year,fecha_ingreso, curdate()) as antigüedad
from empleados
order by ingreso desc;

#2
select min(precio) 'menor precio' from libros;

#3
select min(precio) 'menor precio', max(precio) 'mayor precio' from libros;

#4
select min(precio) 'menor precio', max(precio) 'mayor precio',  round(avg(precio), 2) as 'precio promedio'  from libros;

#5
select categoria, min(precio) 'menor precio', max(precio) 'mayor precio',round(avg(precio), 2) as 'precio promedio' from libros group by categoria;


#6
select categoria, min(precio) 'menor precio', max(precio) 'mayor precio',
round(avg(precio), 2) as 'precio promedio' from libros group by categoria
having categoria != "sin asignar";