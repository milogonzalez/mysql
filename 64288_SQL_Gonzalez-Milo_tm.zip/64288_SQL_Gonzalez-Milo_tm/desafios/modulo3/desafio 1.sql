use bonus_track;
#1
select genero ,concat(artista , "-", titulo) as cancion from top_spotify order by cancion ;

#2
select genero ,concat_ws("-",artista ,titulo) as cancion from top_spotify order by cancion ;
#3
select upper(genero) ,concat_ws("-",artista ,titulo) as cancion from top_spotify order by cancion ;
#4
select upper(genero) ,YEAR(CURDATE())-ano as años  ,concat_ws("-",artista ,titulo) as cancion from top_spotify order by cancion ;
#5
select count(id) as canciones from top_spotify; 

#6
select ano, count(ano) as "canciones en ese año"  from top_spotify group by ano;

#7
select ano, count(ano) as "canciones"  from top_spotify group by ano having canciones>=50;

