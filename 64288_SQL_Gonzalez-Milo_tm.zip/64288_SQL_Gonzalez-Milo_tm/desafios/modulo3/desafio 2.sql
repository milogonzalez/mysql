use libreria;
#1
select provincia ,concat(apellido, "," ,nombre  ) autor from autores order by autor;
#2
select provincia ,concat_ws(",",apellido, nombre  ) autor from autores order by autor;
#3
select provincia ,upper(concat_ws(",",apellido, nombre)) autor from autores order by autor;
#4
select provincia ,upper(concat_ws(",",apellido, left(nombre,1))) autor from autores order by autor;
#5
select concat(apellido, ', ', nombre) empleado, year(fecha_ingreso) as ingreso from empleados order by ingreso desc;
