use libreria;



ALTER TABLE ventas ADD Primary Key(local_id,factura_nro,libro_id);
ALTER TABLE locales ADD Primary Key(local_id);
ALTER TABLE editoriales ADD Primary Key(editorial_id);
ALTER TABLE libros ADD Primary Key(libro_id);
ALTER TABLE libroautor ADD Primary Key(autor_id,libro_id);
ALTER TABLE empleados ADD Primary Key(empleado_id);
ALTER TABLE puestos ADD Primary Key(puesto_id);




