use libreria;

#1

create table empleados_anteriores
select * from empleados where apellido in ('thomas', 'pereira', 'devo');
delete from empleados   where apellido in ('thomas', 'pereira', 'devo');


#2

insert into empleados_anteriores (empleado_id, nombre, apellido,puesto_id, editorial_id, fecha_ingreso, permanencia)
select empleado_id, nombre, apellido, puesto_id, editorial_id,fecha_ingreso, permanencia from empleados where apellido = 'cruz';
delete from empleados where apellido = 'cruz';