use bonus_track;
#2
select * from top_spotify;
#3
select artista , titulo , genero from top_spotify ;
#4
select artista , titulo , genero from top_spotify order by genero ;
#5
select artista , titulo , genero from top_spotify order by genero , artista;

