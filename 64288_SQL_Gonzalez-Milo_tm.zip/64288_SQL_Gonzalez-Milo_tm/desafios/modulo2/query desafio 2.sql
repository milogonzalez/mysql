use bonus_track;


#1
select artista , titulo , genero from top_spotify order by artista , titulo limit 10;

#2
select artista , titulo , genero from top_spotify order by artista , titulo limit 5 offset 10;
#3
select * from top_spotify where artista = "madonna";
#4
select * from top_spotify where genero = "pop" order by titulo;
#5
select * from top_spotify where genero = "pop" and ano=2015 order by artista,titulo;
#6
select * from top_spotify where genero = "dance pop" and ano<2011 order by titulo;

