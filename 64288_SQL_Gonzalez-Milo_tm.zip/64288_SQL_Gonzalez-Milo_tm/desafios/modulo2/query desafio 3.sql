use libreria;

#1
select * from autores where ciudad = "buenos aires";
#2
select * from libros where precio>30 order by precio;
#3
select * from autores where provincia != "ba" order by nombre;
#4
select * from libros where categoria="cuentos" and precio <20 order by titulo;
#5
select * from libros where categoria="novelas" or categoria ="ensayos" order by titulo;
#6
select * from libros where precio between 20 and 35 order by precio;
#7
select * from autores where nombre in ("jorge luis" , "victoria" , "ernesto","adolofo")order by nombre;
#8
select * from libros where titulo like  "%mundo%" ORDER BY TITULO;
#9
select * from libros where titulo like "%de%" ORDER BY TITULO;
#10
select * from libros where precio is null order by titulo;
