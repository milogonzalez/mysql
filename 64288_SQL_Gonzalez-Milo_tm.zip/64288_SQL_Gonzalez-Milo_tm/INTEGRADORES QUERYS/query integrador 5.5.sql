use laboratoriobackup ; 

#1
select pn.nombrecontacto, idproducto, nombreproducto, preciounidad from proveedores p join productos_neptuno pn
on p.idproveedor = pn.idproveedor order by pn.nombrecontacto, nombreproducto;

#2
select pn.nombrecontacto, idproducto, nombreproducto, preciounidad from proveedores p join productos_neptuno pn
where p.idproveedor = pn.idproveedor order by pn.nombrecontacto, nombreproducto;

#3
select empresa, numero_pedido, fecha_pedido, forma_pago from clientes c join pedidos p
on c.cod_cliente = p.codigo_cliente order by empresa;

#4
select empresa, numero_pedido, fecha_pedido, forma_pago from clientes c left join pedidos p
on c.cod_cliente = p.codigo_cliente where p.numero_pedido is null order by empresa;

#5
select empresa from clientes c left join pedidos p
on c.cod_cliente = p.codigo_cliente where p.numero_pedido is null order by empresa;

#6
select * from proveedores p left join productos_neptuno pn
on p.idproveedor = pn.idproveedor where pn.idproducto is null;

#7
select * from proveedores p right join productos_neptuno pn
on p.idproveedor = pn.idproveedor where p.idproveedor is null;