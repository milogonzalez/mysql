use laboratoriobackup;

#1
select count(*) from pedidos_neptuno;

#2
select count(Transportista) as " ENTREGAS SPEEDY EXPRESS"   from pedidos_neptuno where Transportista = "speedy express" ;

#3
select count(empleado) as "VENTAS" from pedidos_neptuno where left(empleado,1)="c"  ;

#4
select round(avg(preciounidad),2) as "preciopromedio" from productos_neptuno;

#5
select round(avg(preciounidad),2) as "precio promedio" , min(PrecioUnidad) as "precio inferior" from productos_neptuno;

#6
select round(avg(preciounidad),2) as "precio promedio" , 
min(PrecioUnidad) as "precio inferior",
max(preciounidad) as "precio maximo" from productos_neptuno;

#7
select nombrecategoria as CATEGORIA, max(preciounidad) as "precio maximo" from productos_neptuno group by categoria  ;

#8
select Transportista , count(Transportista) as ENTREGAS from pedidos_neptuno group by Transportista;

 #9
 select SEXO , count(SEXO) as NACIMIENTOS FROM NACIMIENTOS GROUP BY SEXO;
 
 #10
 
 select nombrecompania as cliente , round(sum(cargo),2) as "total gastos" from pedidos_neptuno group by cliente;
 
 #11
 
 select seccion , count(cod_producto) as cantidad from productos group by seccion order by cantidad desc ;
 


 
 #12
 select year(fechapedido) as "año", 
 monthname(fechapedido) as "mes",
 count(idpedido) as ventas 
 from pedidos_neptuno 
 group by año, mes 
 order by año , 
 month(fechapedido);
 
 #13
 
 select empleado,
round(sum(cargo), 2) as facturacion,
round(avg(cargo), 2) as promedio,
max(cargo) as 'mejor venta',
min(cargo) as 'peor venta',
count(cargo) as ventas
from pedidos_neptuno
group by empleado;
 
 
 
 
