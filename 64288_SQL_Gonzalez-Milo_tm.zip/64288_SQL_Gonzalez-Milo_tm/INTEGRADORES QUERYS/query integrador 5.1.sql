use laboratoriobackup;

#1
select * from productos_neptuno where preciounidad> 
(select avg(preciounidad) from productos_neptuno) order by nombreproducto;


#2
select * from productos_neptuno where preciounidad> 
(select max(preciounidad) from productos_suspendidos);

#3
select * from varones where semanas < 
(select min(semanas) from indeterminados);

#4
select * from productos_neptuno where left(nombreproducto, 1) =
(select left(nombre_empleado, 1) from empleados where idempleado = 8) order by nombreproducto;

#5
select * from productos_neptuno where idproveedor =
(select max(idproveedor) from proveedores) order by nombreproducto;

#6
select * from productos_neptuno where nombrecategoria = 'bebidas' and preciounidad >
(select max(preciounidad) from productos_neptuno where nombrecategoria = 'condimentos');

#7
select * from mujeres where edad_madre>
(select max(edad_madre) from varones);

#8  no encontre las tablas que coincidan los campos para igualar los campos
select * from clientes_neptuno where idcliente in
(select idcliente from facturas where monto>500)


