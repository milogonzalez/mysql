USE laboratoriobackup;

set sql_safe_updates = 0;
delete from productos_neptuno
where suspendido = 'si';