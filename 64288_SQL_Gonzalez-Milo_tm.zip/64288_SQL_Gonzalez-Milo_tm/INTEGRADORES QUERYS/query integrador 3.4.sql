use laboratoriobackup;

#1
select * , round(cargo*0.21, 2) as IVA from pedidos_neptuno;

#2
select * , round(cargo*0.21, 2) as IVA , round(cargo*1.21, 2) as NETO from pedidos_neptuno;

#3
select * , round(cargo*0.21, 2) as IVA ,
 round(cargo*1.21, 2) as NETO, 
 floor(round(cargo*1.21, 2)) as "REDONDEO A
FAVOR CLIENTE" from pedidos_neptuno;

#4
select * , round(cargo*0.21, 2) as IVA ,
 round(cargo*1.21, 2) as NETO, 
 floor(round(cargo*1.21, 2)) as "REDONDEO A
FAVOR CLIENTE",
 ceil(round(cargo*1.21, 2)) as "REDONDEO A
FAVOR EMPRESA" from pedidos_neptuno;