use laboratoriobackup;

#1
select * from pedidos_neptuno where year(fechapedido)=1998; 

#2
select * from pedidos_neptuno where month(fechapedido) between 8 and 9 and year(fechapedido)=1997;
#3
select * from pedidos_neptuno where day(fechapedido) = 1 ;

#4
select * , DATEDIFF(curdate(),fechapedido) as 'DIAS TRANSCURRIDOS'from pedidos_neptuno;

#5
select * , DATEDIFF(curdate(),fechapedido) as 'DIAS TRANSCURRIDOS',
 dayname(fechapedido) as "DIA" from pedidos_neptuno;

#6
select * , DATEDIFF(curdate(),fechapedido) as 'DIAS TRANSCURRIDOS',
 dayname(fechapedido) as "DIA",
 DAYOFYEAR(fechapedido) as"DIA DEL AÑO" from pedidos_neptuno;
 
 #7
 select * , DATEDIFF(curdate(),fechapedido) as 'DIAS TRANSCURRIDOS',
 dayname(fechapedido) as "DIA",
 DAYOFYEAR(fechapedido) as"DIA DEL AÑO" ,
 monthname(fechapedido) as "MES" from pedidos_neptuno;
 
 #8
select * , DATEDIFF(curdate(),fechapedido) as 'DIAS TRANSCURRIDOS',
 dayname(fechapedido) as "DIA",
 DAYOFYEAR(fechapedido) as"DIA DEL AÑO" ,
 monthname(fechapedido) as "MES",
 adddate(fechapedido, interval 30 day) "vencimiento 30 dias" from pedidos_neptuno;
 
 #9
 select * , DATEDIFF(curdate(),fechapedido) as 'DIAS TRANSCURRIDOS',
 dayname(fechapedido) as "DIA",
 DAYOFYEAR(fechapedido) as"DIA DEL AÑO" ,
 monthname(fechapedido) as "MES",
 adddate(fechapedido, interval 30 day) "vencimiento 30 dias",
 adddate(fechapedido, interval 2 month) "vencimiento 2 meses" from pedidos_neptuno;
 
 


