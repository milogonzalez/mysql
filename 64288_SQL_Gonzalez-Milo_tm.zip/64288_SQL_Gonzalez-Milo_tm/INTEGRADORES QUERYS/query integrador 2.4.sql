use laboratorio;

#punto 1
SELECT * FROM NACIMIENTOS WHERE NACIONALIDAD = 'EXTRANJERA';

#punto 2
SELECT * FROM NACIMIENTOS WHERE EDAD_MADRE < 18 ORDER BY EDAD_MADRE;

#punto 3
SELECT * FROM NACIMIENTOS WHERE EDAD_MADRE = EDAD_PADRE;

#punto 4
SELECT * FROM NACIMIENTOS WHERE EDAD_PADRE-EDAD_MADRE > 40;

#punto 5
SELECT * FROM CLIENTES_NEPTUNO WHERE PAIS = 'ARGENTINA';

#punto 6
SELECT * FROM CLIENTES_NEPTUNO where pais != "argentina" order by pais;

#punto 7

select * from nacimientos where semanas<20 order by semanas desc;

#punto 8 

select * from nacimientos where sexo = "femenino"  and nacionalidad = "extranjera" and estado_civil_madre ="soltera" and edad_madre >40;

#punto 9

select * from clientes_neptuno where pais = "argentina" or pais = "brasil" or pais = "venezuela" order by pais, ciudad;

#punto 10

select * from nacimientos where semanas>=20 and semanas<=25 order by semanas;

#punto 11

select * from nacimientos where comuna in (1101, 3201,5605, 8108, 9204, 13120 , 15202) order by comuna;

#punto 12

select * from  clientes_neptuno where idcliente like "c%" ;

#punto 13

select * from clientes_neptuno where ciudad like "b____" ;

#punto 14

select * from nacimientos where hijos_total >10;


