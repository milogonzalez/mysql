use laboratoriobackup;

#1
create table varones select * from nacimientos where sexo = "masculino" ;

#2
create table mujeres select * from nacimientos where sexo = "femenino" ;

#3
create table indeterminados select * from nacimientos where sexo = "indeterminado" ;

#4
drop table nacimientos;


