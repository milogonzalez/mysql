use laboratoriobackup;

#1A
update productos_neptuno set suspendido = "SI" where IDPROVEEDOR=1;
SELECT * FROM productos_neptuno;

#1B
INSERT into productos_suspendidos (IdProducto, NombreProducto, NombreContacto, NombreCategoria, PrecioUnidad, suspendido, IdProveedor)
select IdProducto ,NombreProducto, NombreContacto, NombreCategoria, PrecioUnidad, suspendido, IdProveedor 
from productos_neptuno 
where suspendido="si";

#1C
delete from productos_neptuno where suspendido = 'si';
