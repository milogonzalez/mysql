create DATABASE LABORATORIO;
USE LABORATORIO;

#CREACION TABLAS

CREATE TABLE FACTURAS (
Letra CHAR,
Numero int,
ClienteID int,
ArticuloID int ,
Fecha date , 
monto double,
PRIMARY KEY (Letra,Numero)
) ;
CREATE TABLE ARTICULOS (
ArticuloID int ,
Nombre varchar(50),
Precio double ,
Stock int,
PRIMARY KEY (ArticuloID)
) ;

CREATE TABLE CLIENTES (
ClienteID int,
Nombre varchar (25),
Apellido varchar(25),
CUIT CHAR(16),
Direccion varchar(50),
Comentarios varchar(50),
PRIMARY KEY (ClienteID)
) ;
#--------------------------------------------------------------------
SHOW DATABASES;
#SHOW TABLES;
DESC CLIENTES;





