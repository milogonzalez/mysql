 use laboratorio;
 
 
 # punto 2 a ,b,c
 alter table clientes_neptuno modify idcliente varchar(5) primary key,
							modify nombrecompania varchar(100) not null,
							modify pais varchar (15) not null;

# punto 3
 rename table clientes to contactos;
 
 #punto 5 a b c d e
 
 alter table clientes modify cod_cliente varchar(7) primary key,
					modify empresa varchar(100) not null,
					modify ciudad varchar(25) not null,
                    modify telefono int unsigned ,
                    modify responsable varchar(30);



# punto 7a b c d e


alter table pedidos modify numero_pedido int primary key,
					modify codigo_cliente varchar(7) not null,
                    modify fecha_pedido date not null,
                    modify forma_pago enum ( "contado", "aplazado" ,"tarjeta"),
                    modify enviado enum("si", "no");
                    

#punto 9 a b c d e f

alter table productos modify cod_producto int primary key,
					modify seccion varchar(20) not null,
                    modify nombre varchar(40) not null,
                    modify importado enum ("verdadero" , "falso"),
                    modify origen varchar (25) not null,
                    modify dia int unsigned not null,
                    modify mes int unsigned not null,
                    modify ano int unsigned not null;
                    




	
 
 
 
 