use laboratorio;

#punto 1
select * from clientes_neptuno;
#punto 2
select nombrecompania , ciudad, pais  from clientes_neptuno;
#punto 3
select nombrecompania , ciudad, pais  from clientes_neptuno order by pais ASC;
#punto 4
select nombrecompania , ciudad, pais  from clientes_neptuno order by pais,ciudad ASC;
#punto 5
select nombrecompania , ciudad, pais  from clientes_neptuno order by pais ASC limit 10;
#punto 6
select nombrecompania , ciudad, pais  from clientes_neptuno order by pais ASC limit 5 offset 10;





