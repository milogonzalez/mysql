use  laboratorio;


#MODIFICACION TABLA FACTURAS
ALTER TABLE FACTURAS CHANGE CLIENTEID IDCLIENTE INT,
					CHANGE ARTICULOID IDArticulo INT,
                    MODIFY MONTO DOUBLE UNSIGNED;
 
 #MODIFICACION TABLA ARTICULOS
 
 ALTER TABLE ARTICULOS CHANGE ArticuloID IDArticulo INT ,
						MODIFY Nombre varchar(75),
                        MODIFY Precio double UNSIGNED NOT NULL ,
                        MODIFY Stock int UNSIGNED NOT NULL;

#MODIFICACION TABLA CLIENTES

ALTER TABLE CLIENTES CHANGE  Clienteid IDCliente int , 
					MODIFY Nombre varchar(30) NOT NULL,
                    MODIFY Apellido varchar(35) not null,
                    change comentarios observaciones varchar(255);
                    
                    