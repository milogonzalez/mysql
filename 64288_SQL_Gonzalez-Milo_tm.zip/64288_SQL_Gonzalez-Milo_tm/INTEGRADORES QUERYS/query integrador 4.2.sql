use laboratoriobackup;
SET SQL_SAFE_UPDATES = 0;

#1
update clientes_neptuno set pais="USA" where pais="estados unidos"; 
select  * from clientes_neptuno  where pais = "USA";

#2
update clientes_neptuno set nombrecompania=upper(nombrecompania);
select  * from clientes_neptuno;

#3
update clientes_neptuno set ciudad=upper(ciudad) , pais=upper(pais);
select  * from clientes_neptuno;

#4
alter table empleados add column nombre_empleado varchar(30) after idempleado;
update empleados set nombre_empleado =concat_ws(", ",apellidos,nombre);
alter table empleados drop apellidos , drop nombre ;
select * from empleados;

#5
alter table clientes add column tipo varchar(3);
update clientes set tipo = "VIP" where ciudad= "MADRID";
SELECT * FROM CLIENTES;

#6
alter table clientes modify telefono varchar (30);
update clientes set TELEFONO =concat("+34-",TELEFONO) where tipo is not null;
SELECT * FROM CLIENTES;


#7
alter table productos add column fecha date;
update productos set fecha = concat(ano ,"," , mes , ",", dia);
alter table productos drop dia , drop mes , drop ano;
update productos set origen="ESPAÑA" WHERE origen="espana";
select * from productos;

#8
alter table productos_neptuno modify suspendido char (2);
update productos_neptuno set suspendido="NO" where suspendido= 0;
update productos_neptuno set suspendido="SI" where suspendido= 1;
select * from productos_neptuno;


#9
select * from productos_neptuno;

update productos_neptuno set preciounidad = round(preciounidad*1.10 , 2);
select * from productos_neptuno;

#10
update proveedores set region = null where region = '';
select * from proveedores;

#11
update clientes
set ciudad = concat(upper(left(ciudad, 1)),
lower(substring(ciudad, 2, length(ciudad))));
select * from clientes;


#12
create table productos_suspendidos
select * from productos_neptuno
where suspendido = 'si';
select * from productos_suspendidos;






