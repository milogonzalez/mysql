use laboratoriobackup ;


#1

select idcliente, nombrecompania, ciudad, pais,
case
when pais in ('argentina', 'brasil', 'venezuela') then 'america del sur'
when pais in ('méxico', 'usa', 'canadá') then 'america del norte'
else 'europa'
end as continente
from clientes_neptuno
order by continente, pais;

#2

select idpedido, nombrecompania, fechapedido, cargo,
case
when cargo > 700 then 'excelente'
when cargo > 500 then 'muy bueno'
when cargo > 250 then 'bueno'
when cargo > 50 then 'regular'
else 'malo'
end as 'evaluacion'
from pedidos_neptuno
order by cargo desc;

#3
select idproducto, nombreproducto, nombrecategoria, preciounidad,
case
when preciounidad > 100 then 'deluxe'
when preciounidad > 10 then 'regular'
else 'economico'
end as tipo
from productos_neptuno
order by preciounidad desc;

