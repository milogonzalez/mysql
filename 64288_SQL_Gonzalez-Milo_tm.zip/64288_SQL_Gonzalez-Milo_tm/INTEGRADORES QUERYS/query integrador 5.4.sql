use laboratoriobackup ;

#1
create table equipos (
equipo varchar(20)  primary key);

#2
insert into equipos
values ('argentina'), ('brasil'), ('chile'), ('paraguay'), ('uruguay'),
('colombia'), ('ecuador'), ('perú'), ('bolivia'), ('venezuela');

#3
select * from equipos L cross join equipos V where l.equipo<>v.equipo order by L.equipo ;

#4
select IDPRODUCTO, NOMBREPRODUCTO ,NOMBRE_EMPLEADO from PRODUCTOS_NEPTUNO idp cross join empleados ide where idp.idproducto=ide.idempleado;
