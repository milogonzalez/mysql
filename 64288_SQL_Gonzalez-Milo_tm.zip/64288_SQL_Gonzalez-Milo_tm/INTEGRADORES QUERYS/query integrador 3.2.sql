use laboratoriobackup;

#1
select idcliente , nombrecompania , concat(direccion, "-" , ciudad , "-" , pais) as "ubicacion" from clientes_neptuno;

#2
select idcliente , nombrecompania , concat_ws("-", direccion , ciudad,pais) as "ubicacion" from clientes_neptuno;

#3
select idcliente , concat_ws("-", direccion , ciudad,pais) as "ubicacion" , 
upper(nombrecompania) as "empresa" from clientes_neptuno;

#4
select  concat_ws("-", direccion , ciudad,pais) as "ubicacion" , 
upper(nombrecompania) as "empresa", 
lower(idcliente) as "codigo" from clientes_neptuno;

#5
select fecha , concat(left(sexo,1)," ") as sexo , 
concat(left(tipo_parto,1)) as tipo from nacimientos;

#6
select * ,upper(concat(left(ciudad,1),left(pais ,1),right(pais,2))) as "codigo" from clientes_neptuno;

#7
SELECT SEXO, FECHA, TIPO_PARTO, ATENC_PART, LOCAL_PART, substring(fecha ,4,2) as "mes" from nacimientos order by mes;

#8
SELECT SEXO, FECHA, TIPO_PARTO , replace(nacionalidad, "chilena","ciudadana") as nacionalidad from nacimientos;

