use laboratoriobackup ; 

#1
select * from varones where semanas <20
union
select * from mujeres where semanas <20
union
select * from indeterminados where semanas <20 ;


#2
select * from varones where fecha like '%/09/%' and nacionalidad = 'chilena' and estado_civil_madre = 'casada' and semanas > 40
union
select * from mujeres where fecha like '%/09/%' and nacionalidad = 'chilena' and estado_civil_madre = 'casada' and semanas > 40
union
select * from indeterminados where fecha like '%/09/%' and nacionalidad = 'chilena' and estado_civil_madre = 'casada' and semanas > 40;

#3
select *from productos_neptuno where preciounidad > 80
union
select * from productos_suspendidos where preciounidad > 80 order by nombreproducto;

#4
select *, 'a la venta' as condicion from productos_neptuno where preciounidad > 80
union
select *, 'suspendido' as condicion from productos_suspendidos where preciounidad > 80 order by nombreproducto;

#5
select * from productos_neptuno where nombrecategoria = 'bebidas'
union
select * from productos_suspendidos where nombrecategoria = 'bebidas' order by nombreproducto;

#6
insert into productos_suspendidos (idproducto, nombreproducto, nombrecontacto, nombrecategoria, preciounidad, suspendido, idproveedor)
select idproducto, nombreproducto, nombrecontacto, nombrecategoria,preciounidad, suspendido, idproveedor from productos_neptuno where idproducto = 43 ;

#7

select * from productos_neptuno where nombrecategoria = 'bebidas'
union
select * from productos_suspendidos where nombrecategoria = 'bebidas' order by nombreproducto;

#8
select * from productos_neptuno where nombrecategoria = 'bebidas'
union all
select * from productos_suspendidos where nombrecategoria = 'bebidas' order by nombreproducto;

#9
set sql_safe_updates = 0;
delete from productos_suspendidos where idproducto = 43;
